import express from 'express';
import messagesController from '../controllers/messagesController.js';
const router = express.Router();

router.get('/:conversationId', messagesController.getMessagesByConversation);
router.post('/send', messagesController.sendMessage);

export default router;

import { sendTemplate } from "../controllers/templateController.js";

router.post("/template", sendTemplate);
