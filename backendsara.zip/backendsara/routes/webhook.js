import express from 'express';
import controller from '../controllers/webhookController.js';
const router = express.Router();

router.get('/', controller.verifyToken);
router.post('/', controller.receiveMessage);

export default router;
