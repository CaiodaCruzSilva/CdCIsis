import express from 'express';
import convController from '../controllers/conversationsController.js';
const router = express.Router();

router.get('/', convController.listConversations);
router.get('/:id', convController.getConversation);

export default router;
