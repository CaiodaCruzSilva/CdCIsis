import Conversation from '../models/Conversation.js';
import Contact from '../models/Contact.js';

export default {
  async listConversations(req, res) {
    try {
      const convs = await Conversation.find().sort({ updatedAt: -1 }).populate('contactId');
      return res.json(convs);
    } catch (err) {
      console.error(err);
      return res.sendStatus(500);
    }
  },

  async getConversation(req, res) {
    try {
      const conv = await Conversation.findById(req.params.id).populate('contactId');
      if (!conv) return res.sendStatus(404);
      return res.json(conv);
    } catch (err) {
      console.error(err);
      return res.sendStatus(500);
    }
  }
};
