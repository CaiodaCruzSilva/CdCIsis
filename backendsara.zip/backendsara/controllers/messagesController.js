import Message from '../models/Message.js';
import Conversation from '../models/Conversation.js';
import Contact from '../models/Contact.js';
import { sendMessage } from "../services/whatsappService.js";


export default {
  async getMessagesByConversation(req, res) {
    try {
      const { conversationId } = req.params;
      const messages = await Message.find({ conversationId }).sort({ createdAt: 1 });
      return res.json(messages);
    } catch (err) {
      console.error(err);
      return res.sendStatus(500);
    }
  },
 
  async sendMessage(req, res) {
    try {
      const { to, body, conversationId } = req.body;
      if (!to || !body) return res.status(400).json({ error: 'to and body required' });

      await sendMessage(to, body);

      const msg = await Message.create({ conversationId, from: 'me', to, body, direction: 'outbound' });

      if (conversationId) {
        const conv = await Conversation.findById(conversationId);
        if (conv) {
          conv.lastMessage = body;
          await conv.save();
        }
      }

      return res.json(msg);
    } catch (err) {
      console.error('sendMessage erro', err.response?.data || err.message);
      return res.status(500).json({ error: 'failed to send' });
    }
  }
};