import { sendTemplateMessage } from "../services/whatsappService.js";

export async function sendTemplate(req, res) {
  try {
    const { to, template, variables, language } = req.body;

    await sendTemplateMessage(
      to,
      template,
      variables || [],
      language || "en_US"
    );

    res.json({ success: true });
  } catch (err) {
    console.error("Erro template:", err.response?.data || err.message);
    res.status(500).json({ error: "failed to send template" });
  }
}
