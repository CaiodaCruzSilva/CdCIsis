import Message from '../models/Message.js';
import Contact from '../models/Contact.js';
import Conversation from '../models/Conversation.js';

const VERIFY_TOKEN = process.env.VERIFY_TOKEN;

export default {
  verifyToken(req, res) {
    const mode = req.query['hub.mode'];
    const token = req.query['hub.verify_token'];
    const challenge = req.query['hub.challenge'];

    if (mode === 'subscribe' && token === VERIFY_TOKEN) {
      return res.status(200).send(challenge);
    }
    return res.sendStatus(403);
  },

  async receiveMessage(req, res) {
    try {
      const entry = req.body.entry?.[0]?.changes?.[0]?.value;
      const msg = entry?.messages?.[0];
      if (!msg) return res.sendStatus(200);

      const from = msg.from;
      const body = msg.text?.body || msg?.image?.caption || '';

      let contact = await Contact.findOne({ phone: from });
      if (!contact) contact = await Contact.create({ phone: from });

      let conversation = await Conversation.findOne({ contactId: contact._id });
      if (!conversation) {
        conversation = await Conversation.create({ contactId: contact._id, lastMessage: body });
      } else {
        conversation.lastMessage = body;
        await conversation.save();
      }

      await Message.create({ conversationId: conversation._id, from, to: 'me', body, direction: 'inbound', metadata: msg });

      return res.sendStatus(200);
    } catch (err) {
      console.error('Webhook erro', err);
      return res.sendStatus(500);
    }
  }
};
