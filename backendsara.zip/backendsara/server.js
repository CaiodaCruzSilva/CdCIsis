import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';

import webhookRoute from './routes/webhook.js';
import messagesRoute from './routes/messages.js';
import conversationsRoute from './routes/conversations.js';

const app = express();
app.use(express.json());
app.use(cors());

mongoose.set('strictQuery', false);
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB conectado'))
  .catch(err => console.error('MongoDB erro', err));

app.use('/webhook', webhookRoute);
app.use('/messages', messagesRoute);
app.use('/conversations', conversationsRoute);

app.get('/', (req, res) => res.send('WhatsApp CRM Backend ativo'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
