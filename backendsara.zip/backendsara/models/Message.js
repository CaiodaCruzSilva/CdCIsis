import mongoose from 'mongoose';
const { Schema } = mongoose;

const MessageSchema = new Schema({
  conversationId: { type: Schema.Types.ObjectId, ref: 'Conversation' },
  from: String,
  to: String,
  body: String,
  direction: { type: String, enum: ['inbound','outbound'], default: 'inbound' },
  metadata: { type: Schema.Types.Mixed }
}, { timestamps: true });

export default mongoose.model('Message', MessageSchema);
