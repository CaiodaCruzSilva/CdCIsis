import mongoose from 'mongoose';
const { Schema } = mongoose;

const ConversationSchema = new Schema({
  contactId: { type: Schema.Types.ObjectId, ref: 'Contact' },
  lastMessage: { type: String },
  status: { type: String, default: 'open' }
}, { timestamps: true });

export default mongoose.model('Conversation', ConversationSchema);
