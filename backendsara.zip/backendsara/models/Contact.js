import mongoose from 'mongoose';
const { Schema } = mongoose;

const ContactSchema = new Schema({
  phone: { type: String, unique: true },
  name: { type: String, default: null }
}, { timestamps: true });

export default mongoose.model('Contact', ContactSchema);
