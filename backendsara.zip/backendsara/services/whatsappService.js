import axios from "axios";

const BASE_URL = `https://graph.facebook.com/v19.0/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`;

export async function sendMessage(to, body) {
  const payload = {
    messaging_product: "whatsapp",
    to,
    type: "text",
    text: { body }
  };

  return axios.post(BASE_URL, payload, {
    headers: {
      Authorization: `Bearer ${process.env.WHATSAPP_TOKEN}`,
      "Content-Type": "application/json"
    }
  });
}

export async function sendTemplateMessage(to, templateName, variables = [], language = "en_US") {
  const components = [];

  if (variables.length > 0) {
    components.push({
      type: "body",
      parameters: variables.map(v => ({
        type: "text",
        text: String(v)
      }))
    });
  }

  const payload = {
    messaging_product: "whatsapp",
    to,
    type: "template",
    template: {
      name: templateName,
      language: { code: language },
      components
    }
  };

  return axios.post(BASE_URL, payload, {
    headers: {
      Authorization: `Bearer ${process.env.WHATSAPP_TOKEN}`,
      "Content-Type": "application/json"
    }
  });
}

console.log("PHONE ID:", process.env.WHATSAPP_PHONE_NUMBER_ID);
